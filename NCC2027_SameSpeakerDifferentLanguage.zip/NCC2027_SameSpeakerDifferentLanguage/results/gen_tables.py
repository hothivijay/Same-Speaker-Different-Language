#!/usr/bin/env python3
"""Write the result tables of main.tex from values.json (made by parse_results.py).

usage: python gen_tables.py values.json main.tex
Every number in a table comes straight from the logs; nothing is typed by hand.
"""
import json
import re
import sys


def f(x, d=2):
    return "--" if x is None else f"{x:.{d}f}"


def pval(p):
    if p is None:
        return "--"
    if p < 0.001:
        return r"$<$0.001"
    return f"{p:.3f}" if p < 0.1 else f"{p:.2f}"


def ci(s, d=2):
    return f"[{s['lo']:+.{d}f}, {s['hi']:+.{d}f}]"


def table(label, caption, colspec, header, rows, tabcolsep=None, size="small"):
    sep = f"\\setlength{{\\tabcolsep}}{{{tabcolsep}}}\n" if tabcolsep else ""
    body = " \\\\\n".join(rows) + " \\\\"
    return (f"\\begin{{table}}[t]\n\\centering\n\\caption{{{caption}}}\n\\label{{{label}}}\n\\{size}\n{sep}"
            f"\\begin{{tabular}}{{{colspec}}}\n\\toprule\n{header} \\\\\n\\midrule\n{body}\n\\bottomrule\n\\end{{tabular}}\n\\end{{table}}")


def replace_table(tex, label, block):
    i = tex.index(f"\\label{{{label}}}")
    a = tex.rindex("\\begin{table}", 0, i)
    b = tex.index("\\end{table}", i) + len("\\end{table}")
    return tex[:a] + block + tex[b:]


def main():
    v = json.load(open(sys.argv[1]))
    tex = open(sys.argv[2]).read()
    sd, se, d = v["sim_dev"], v["sim_eval"], v["dia"]
    ev = d["events"]

    # Table I
    rows = [r"Recordings / hours & 35 / $\approx$20 & 32 / $\approx$18",
            f"Speakers; max.\\ per recording & 98; {d['maxspk'][0]} & 99; {d['maxspk'][1]}",
            f"Windows used in analysis (\\%) & {f(sd['windows_used'], 1)} & {f(se['windows_used'], 1)}",
            f"Multilingual speakers & {sd['n_ml']} & {se['n_ml']}",
            f"Within-speaker switches / h & {f(ev['dev']['ws'][1], 0)} & {f(ev['eval']['ws'][1], 0)}",
            f"Switches at a speaker change / h & {f(ev['dev']['sc'][1], 0)} & {f(ev['eval']['sc'][1], 0)}",
            f"Speaker changes, same language / h & {f(ev['dev']['spk'][1], 0)} & {f(ev['eval']['spk'][1], 0)}"]
    tex = replace_table(tex, "tab:data", table("tab:data", r"DISPLACE 2024 labelled data and code-switching events ($r=1$\,s, $g=2$\,s).",
                                               "lcc", " & Dev. & Eval.", rows, "4pt"))

    # Table II
    def drow(s):
        return f"{s['mean']:.3f} [{s['lo']:.3f}, {s['hi']:.3f}]"
    rows = [f"$\\rho_{{\\mathrm{{same}}}}$ / $\\rho_{{\\mathrm{{cross}}}}$ (mean) & {f(sd['same'], 3)} / {f(sd['cross'], 3)} & {f(se['same'], 3)} / {f(se['cross'], 3)}",
            f"Drift $\\Delta\\rho$ [CI] & {drow(sd['drift'])} & {drow(se['drift'])}",
            f"Time-matched drift & {sd['drift_tm']['mean']:+.3f} & {se['drift_tm']['mean']:+.3f}",
            f"Wilcoxon $p$; $r_{{\\mathrm{{rb}}}}$ & {pval(sd['drift']['p'])}; {sd['drift']['r']:+.2f} & {pval(se['drift']['p'])}; {se['drift']['r']:+.2f}",
            f"Probe bal.\\ acc.\\ (\\%) [CI] & {f(sd['probe'][0], 1)} [{f(sd['probe'][1], 1)}, {f(sd['probe'][2], 1)}] & {f(se['probe'][0], 1)} [{f(se['probe'][1], 1)}, {f(se['probe'][2], 1)}]",
            f"Probe macro-F1 (\\%) & {f(sd['probe'][3], 1)} & {f(se['probe'][3], 1)}",
            f"Chance / majority class (\\%) & {f(sd['chance'][0], 1)} / {f(sd['chance'][1], 1)} & {f(se['chance'][0], 1)} / {f(se['chance'][1], 1)}"]
    tex = replace_table(tex, "tab:drift", table("tab:drift", "H1: same-speaker similarity across languages and language probe (original TitaNet-L embeddings).",
                                                "lcc", " & Development & Evaluation", rows, "3pt", "footnotesize"))

    # Table III
    names = {"SS-SL": "SS-SL: same speaker, same language", "SS-DL": "SS-DL: within-speaker switch",
             "DS-SL": "DS-SL: speaker change only", "DS-DL": "DS-DL: speaker change and switch"}
    rows = [f"{names[k]} & {f(d['base'][k][0], 1)} & {f(d['base'][k][4])} & {f(d['lsp'][k][4])}" for k in names]
    tex = replace_table(tex, "tab:switch", table("tab:switch", "H2: evaluation confusion (\\%) by condition, NME-SC, oracle speech regions. Share: \\% of reference speech.",
                                                 "lccc", "Condition & Share & Baseline & LSP", rows, "4pt"))

    # Table IV
    rows = [f"0 & 0 & 100 & -- & {f(d['dev']['0']['der'])} & {f(d['dev']['0']['sr'], 1)}"]
    for k in sorted(d["ks"], key=int):
        kk = d["ks"][k]
        dv = d["dev"][str(k)]
        best = int(k) == d["k_best"]
        der = f"\\textbf{{{f(dv['der'])}}}" if best else f(dv["der"])
        rows.append(f"{k} & {f(kk['eps'], 1)} & {f(kk['eta'], 1)} & {f(kk['stab'], 2)} & {der} & {f(dv['sr'], 1)}")
    tex = replace_table(tex, "tab:k", table("tab:k", "Rank selection on the development set (NME-SC, oracle speech; \\%). Stab.: mean bootstrap subspace similarity; bold: chosen $k^\\star$.",
                                            "rccccc", "$k$ & $\\epsilon_k$ & $\\eta_k$ & Stab. & DER & SR", rows, "4pt"))

    # Table V
    def srow(name, s):
        a = s["all"]
        return f"{name} & {f(a[4])} & {f(a[3])} & {f(s['SS-DL'][4]) if s.get('SS-DL') else '--'} & {f(s['sr'][0], 1)} & {f(s['kerr'])}"
    k = d["k_best"]
    rows = [srow("NME-SC", d["base"]), srow(f"NME-SC + LSP ($k={k}$)", d["lsp"]),
            srow("AHC", d["ahc_base"]), srow(f"AHC + LSP ($k={k}$)", d["ahc_lsp"])]
    tex = replace_table(tex, "tab:lsp", table("tab:lsp", "Evaluation set, oracle speech regions, no collar, overlap scored (\\%). SS-DL: confusion at within-speaker switches; SR: split rate; $|\\Delta K|$: mean speaker-count error.",
                                              "lccccc", "System & DER & Conf. & SS-DL & SR & $|\\Delta K|$", rows, "3.2pt"))

    # Table VI
    info = d["info"]

    def mean_info(prefix, key):
        vals = [x[key] for n, x in info.items() if n.startswith(prefix)]
        return sum(vals) / len(vals) if vals else None
    ctrl = d["controls"]
    rows = [f"None & {f(d['base']['all'][4])} & {f(d['base']['sr'][0], 1)} & {mean_info('original', 'drift'):+.3f} & {f(mean_info('original', 'eer'))} & {f(mean_info('original', 'eer_x'))} & {f(mean_info('original', 'probe'), 1)}",
            f"LSP & {f(d['lsp']['all'][4])} & {f(d['lsp']['sr'][0], 1)} & {mean_info('LSP', 'drift'):+.3f} & {f(mean_info('LSP', 'eer'))} & {f(mean_info('LSP', 'eer_x'))} & {f(mean_info('LSP', 'probe'), 1)}"]
    for name, label in (("PCA", "PCA"), ("NAP (within-speaker)", "NAP (within-speaker)"),
                        ("Shifted-label LSP", "Shifted-label LSP"), ("Random", "Random")):
        c = ctrl[name]
        rows.append(f"{label} & {f(c['der'])} & {f(c['sr'], 1)} & {mean_info(name, 'drift'):+.3f} & {f(mean_info(name, 'eer'))} & {f(mean_info(name, 'eer_x'))} & {f(mean_info(name, 'probe'), 1)}")
    tex = replace_table(tex, "tab:ctrl", table("tab:ctrl", "Projections removing $k^\\star$ dimensions (evaluation set, NME-SC; \\%). $\\Delta\\rho$: same-speaker drift; EER$_\\times$: cross-language target pairs; Probe: balanced accuracy. Shifted-label and random rows average three seeds.",
                                               "lcccccc", "Projection & DER & SR & $\\Delta\\rho$ & EER & EER$_\\times$ & Probe", rows, "2.6pt"))

    # Table VII
    th = d["thirds"]
    rows = [f"{n.capitalize()} & {th[n]['n']} & {f(th[n]['lo'], 0)}--{f(th[n]['hi'], 0)} & {f(th[n]['base'])} & {f(th[n]['lsp'])} & {th[n]['gain']:+.2f} [{th[n]['glo']:+.2f}, {th[n]['ghi']:+.2f}]"
            for n in ("low", "middle", "high")]
    tex = replace_table(tex, "tab:rate", table("tab:rate", "Evaluation DER (\\%) of recordings grouped by within-speaker switching rate (NME-SC); gain with 95\\% bootstrap interval.",
                                               "lccccc", "Third & Rec. & Sw./h & Base. & LSP & Gain [CI]", rows, "2.5pt"))
    open(sys.argv[2], "w").write(tex)
    left = len(re.findall(r"\\tbd", tex))
    print("tables written;", left, "\\tbd left in the text (prose)")


if __name__ == "__main__":
    main()
